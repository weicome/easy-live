static const AVCodecParser * const parser_list[] = {
    &ff_aac_latm_parser,
    NULL };
